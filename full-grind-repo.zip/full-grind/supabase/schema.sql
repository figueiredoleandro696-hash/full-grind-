-- =====================================================================
-- FULL GRIND · Schéma Supabase global (v1)
-- À coller dans Supabase > SQL Editor > New query > Run
-- Couvre : comptes, rôles, paiements + preuves, activités, séries,
-- missions, créneaux d'appels, classement anonymisable, stats coach,
-- configuration, sécurité (RLS) et temps réel.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. CODE ÉLÈVE (FG-XXXX)
-- ---------------------------------------------------------------------
create or replace function public.gen_code() returns text
language plpgsql as $$
declare
  a text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  c text; i int;
begin
  loop
    c := 'FG-';
    for i in 1..4 loop
      c := c || substr(a, 1 + floor(random() * length(a))::int, 1);
    end loop;
    exit when not exists (select 1 from public.profiles where code = c);
  end loop;
  return c;
end $$;

-- ---------------------------------------------------------------------
-- 2. TABLES
-- ---------------------------------------------------------------------

-- Profils (1 ligne par compte Supabase Auth)
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  role        text not null default 'student' check (role in ('student','coach')),
  name        text not null,
  email       text not null,
  code        text not null unique default public.gen_code(),
  anon        boolean not null default false,   -- anonyme au classement
  created_at  timestamptz not null default now()
);

-- Paiements déclarés par les élèves (ou ajoutés par le coach)
create table if not exists public.payments (
  id            uuid primary key default gen_random_uuid(),
  student_id    uuid not null references public.profiles(id) on delete cascade,
  amount        numeric(10,2) not null check (amount > 0),
  paid_on       date not null default current_date,
  note          text,
  status        text not null default 'wait' check (status in ('wait','ok','no')),
  proof_path    text,                            -- fichier dans le bucket "proofs"
  validated_by  uuid references public.profiles(id),
  validated_at  timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists payments_student_idx on public.payments(student_id, paid_on desc);
create index if not exists payments_status_idx  on public.payments(status);

-- Activité quotidienne : m = messages de prospection, c = client signé,
-- x = simple "check-in" du jour (compte pour la série)
create table if not exists public.activities (
  id          uuid primary key default gen_random_uuid(),
  student_id  uuid not null references public.profiles(id) on delete cascade,
  day         date not null default current_date,
  kind        text not null check (kind in ('m','c','x')),
  qty         int  not null default 0,
  note        text,
  created_at  timestamptz not null default now(),
  check ((kind = 'x' and qty = 0) or (kind in ('m','c') and qty > 0))
);
create index if not exists activities_student_idx on public.activities(student_id, day desc);

-- Missions du jour (éditables par le coach)
create table if not exists public.missions (
  id        smallint generated always as identity primary key,
  label     text not null,
  position  smallint not null default 0,
  active    boolean not null default true
);

-- Missions cochées, par élève et par jour
create table if not exists public.mission_checks (
  student_id  uuid not null references public.profiles(id) on delete cascade,
  day         date not null default current_date,
  mission_id  smallint not null references public.missions(id) on delete cascade,
  primary key (student_id, day, mission_id)
);

-- Créneaux d'appels ouverts par le coach
create table if not exists public.slots (
  id            uuid primary key default gen_random_uuid(),
  day           date not null,
  start_time    time not null,
  duration_min  int  not null default 30 check (duration_min > 0),
  booked_by     uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  unique (day, start_time)
);
create index if not exists slots_day_idx on public.slots(day, start_time);

-- Configuration globale (1 seule ligne)
create table if not exists public.app_config (
  id                 boolean primary key default true check (id),
  coach_name         text,
  weekly_goal_eur    int not null default 1500,
  weekly_goal_msgs   int not null default 100,
  weekly_goal_clients int not null default 1,
  streak_goal        int not null default 7
);
insert into public.app_config (id) values (true) on conflict do nothing;

-- Missions par défaut
insert into public.missions (label, position)
select v.label, v.position from (values
  ('Envoyer 20 messages de prospection', 1),
  ('Avancer sur un site client ou portfolio', 2),
  ('Relancer les prospects qui n''ont pas répondu', 3),
  ('Noter tes chiffres du jour dans « Mes chiffres »', 4)
) as v(label, position)
where not exists (select 1 from public.missions);

-- ---------------------------------------------------------------------
-- 3. FONCTIONS UTILITAIRES
-- ---------------------------------------------------------------------
create or replace function public.is_coach() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'coach')
$$;

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, name, email)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'name',''), split_part(new.email,'@',1)),
    new.email
  );
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Traçabilité de la validation des paiements
create or replace function public.payments_stamp() returns trigger
language plpgsql as $$
begin
  if new.status in ('ok','no')
     and (tg_op = 'INSERT' or new.status is distinct from old.status) then
    new.validated_by := auth.uid();
    new.validated_at := now();
  elsif new.status = 'wait' then
    new.validated_by := null;
    new.validated_at := null;
  end if;
  return new;
end $$;

drop trigger if exists payments_stamp_trg on public.payments;
create trigger payments_stamp_trg
  before insert or update on public.payments
  for each row execute function public.payments_stamp();

-- Cocher une mission compte comme activité du jour (série)
create or replace function public.mission_checkin() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (
    select 1 from public.activities
    where student_id = new.student_id and day = new.day
  ) then
    insert into public.activities (student_id, day, kind, qty)
    values (new.student_id, new.day, 'x', 0);
  end if;
  return new;
end $$;

drop trigger if exists mission_checkin_trg on public.mission_checks;
create trigger mission_checkin_trg
  after insert on public.mission_checks
  for each row execute function public.mission_checkin();

-- Série de jours consécutifs d'activité (jusqu'à aujourd'hui)
create or replace function public.streak(p_student uuid) returns int
language sql stable as $$
  with d as (
    select distinct day from public.activities
    where student_id = p_student and day <= current_date
  ), g as (
    select day, row_number() over (order by day desc) rn from d
  )
  select coalesce(count(*), 0)::int from g where day = current_date - (rn - 1)::int
$$;

-- ---------------------------------------------------------------------
-- 4. FONCTIONS MÉTIER (appelées via supabase.rpc)
-- ---------------------------------------------------------------------

-- Coach : ouvre des créneaux automatiquement sur une plage horaire
create or replace function public.create_slots(
  p_day date, p_from time, p_to time, p_minutes int default 30
) returns int
language plpgsql security definer set search_path = '' as $$
declare n int;
begin
  if not public.is_coach() then raise exception 'not_allowed'; end if;
  if p_minutes <= 0 then raise exception 'invalid_duration'; end if;
  with ins as (
    insert into public.slots (day, start_time, duration_min)
    select p_day, t::time, p_minutes
    from generate_series(
      p_day + p_from, p_day + p_to - make_interval(mins => p_minutes),
      make_interval(mins => p_minutes)
    ) as t
    on conflict (day, start_time) do nothing
    returning 1
  )
  select count(*) into n from ins;
  return n;
end $$;

-- Élève : réserver un créneau (atomique, impossible de le prendre à deux)
create or replace function public.book_slot(p_slot uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not_allowed'; end if;
  update public.slots set booked_by = auth.uid()
  where id = p_slot and booked_by is null and day >= current_date;
  if not found then raise exception 'slot_taken'; end if;
end $$;

-- Élève : annuler sa réservation
create or replace function public.cancel_slot(p_slot uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.slots set booked_by = null
  where id = p_slot and booked_by = auth.uid();
end $$;

-- Classement (respecte l'option "anonyme" ; p_period = 'month' | 'all')
create or replace function public.leaderboard(p_period text default 'month')
returns table (rank bigint, student_id uuid, display_name text, total numeric, is_me boolean)
language sql stable security definer set search_path = '' as $$
  select
    rank() over (order by coalesce(sum(p.amount), 0) desc),
    case when pr.anon and pr.id <> auth.uid() then null else pr.id end,
    case when pr.anon and pr.id <> auth.uid() then 'Membre anonyme' else pr.name end,
    coalesce(sum(p.amount), 0),
    pr.id = auth.uid()
  from public.profiles pr
  left join public.payments p
    on p.student_id = pr.id
   and p.status = 'ok'
   and (p_period = 'all'
        or date_trunc('month', p.paid_on) = date_trunc('month', current_date))
  where pr.role = 'student' and auth.uid() is not null
  group by pr.id
  order by 4 desc, 3
$$;

-- Chiffres globaux du tableau de bord (total, 8 dernières semaines, 3 derniers encaissements)
create or replace function public.global_stats() returns jsonb
language sql stable security definer set search_path = '' as $$
  select case when auth.uid() is null then null else jsonb_build_object(
    'total', coalesce((select sum(amount) from public.payments where status = 'ok'), 0),
    'weeks', (
      select coalesce(jsonb_agg(jsonb_build_object('week', w, 'total', t) order by w), '[]'::jsonb)
      from (
        select g::date as w,
               coalesce((select sum(p.amount) from public.payments p
                         where p.status = 'ok'
                           and p.paid_on >= g::date and p.paid_on < g::date + 7), 0) as t
        from generate_series(
          date_trunc('week', current_date) - interval '49 days',
          date_trunc('week', current_date),
          interval '7 days') g
      ) x
    ),
    'recent', (
      select coalesce(jsonb_agg(r), '[]'::jsonb) from (
        select case when pr.anon and pr.id <> auth.uid() then 'Membre anonyme' else pr.name end as name,
               p.amount, p.paid_on
        from public.payments p join public.profiles pr on pr.id = p.student_id
        where p.status = 'ok'
        order by p.paid_on desc, p.created_at desc limit 3
      ) r
    )
  ) end
$$;

-- ---------------------------------------------------------------------
-- 5. VUE "SUIVI ÉLÈVES" (coach : tous ; élève : seulement lui-même)
-- ---------------------------------------------------------------------
create or replace view public.student_stats
with (security_invoker = true) as
select
  pr.id as student_id, pr.name, pr.email, pr.code, pr.created_at,
  coalesce(pay.ok_eur, 0)        as validated_eur,
  coalesce(pay.ok_count, 0)      as validated_count,
  coalesce(pay.wait_eur, 0)      as pending_eur,
  coalesce(pay.wait_count, 0)    as pending_count,
  coalesce(pay.month_eur, 0)     as month_eur,
  coalesce(pay.week_eur, 0)      as week_eur,
  pay.last_payment,
  coalesce(act.msgs_7d, 0)       as msgs_7d,
  coalesce(act.msgs_week, 0)     as msgs_week,
  coalesce(act.clients, 0)       as clients,
  coalesce(act.clients_week, 0)  as clients_week,
  act.last_activity,
  public.streak(pr.id)           as streak,
  case
    when act.last_activity is null then 'new'
    when act.last_activity >= current_date - 4 then 'active'
    else 'follow_up'
  end as status
from public.profiles pr
left join lateral (
  select
    sum(p.amount) filter (where p.status = 'ok')   as ok_eur,
    count(*)      filter (where p.status = 'ok')   as ok_count,
    sum(p.amount) filter (where p.status = 'wait') as wait_eur,
    count(*)      filter (where p.status = 'wait') as wait_count,
    sum(p.amount) filter (where p.status = 'ok'
        and date_trunc('month', p.paid_on) = date_trunc('month', current_date)) as month_eur,
    sum(p.amount) filter (where p.status = 'ok'
        and p.paid_on >= date_trunc('week', current_date)::date) as week_eur,
    max(p.paid_on) filter (where p.status = 'ok')  as last_payment
  from public.payments p where p.student_id = pr.id
) pay on true
left join lateral (
  select
    sum(a.qty) filter (where a.kind = 'm' and a.day >= current_date - 7) as msgs_7d,
    sum(a.qty) filter (where a.kind = 'm' and a.day >= date_trunc('week', current_date)::date) as msgs_week,
    sum(a.qty) filter (where a.kind = 'c') as clients,
    sum(a.qty) filter (where a.kind = 'c' and a.day >= date_trunc('week', current_date)::date) as clients_week,
    max(a.day) as last_activity
  from public.activities a where a.student_id = pr.id
) act on true
where pr.role = 'student';

-- ---------------------------------------------------------------------
-- 6. SÉCURITÉ (Row Level Security)
-- ---------------------------------------------------------------------
alter table public.profiles       enable row level security;
alter table public.payments       enable row level security;
alter table public.activities     enable row level security;
alter table public.missions       enable row level security;
alter table public.mission_checks enable row level security;
alter table public.slots          enable row level security;
alter table public.app_config     enable row level security;

-- Profils : chacun voit le sien, le coach voit tout
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_coach());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_coach())
  with check (id = auth.uid() or public.is_coach());
-- (seuls name et anon sont modifiables via l'API, voir les GRANT plus bas)

-- Paiements
create policy pay_select on public.payments for select to authenticated
  using (student_id = auth.uid() or public.is_coach());
create policy pay_insert_student on public.payments for insert to authenticated
  with check (student_id = auth.uid() and status = 'wait');
create policy pay_delete_student on public.payments for delete to authenticated
  using (student_id = auth.uid() and status = 'wait');
create policy pay_coach_all on public.payments for all to authenticated
  using (public.is_coach()) with check (public.is_coach());

-- Activités
create policy act_select on public.activities for select to authenticated
  using (student_id = auth.uid() or public.is_coach());
create policy act_insert on public.activities for insert to authenticated
  with check (student_id = auth.uid());
create policy act_delete on public.activities for delete to authenticated
  using (student_id = auth.uid() or public.is_coach());

-- Missions (lecture pour tous, édition coach)
create policy missions_select on public.missions for select to authenticated using (true);
create policy missions_coach  on public.missions for all to authenticated
  using (public.is_coach()) with check (public.is_coach());

-- Missions cochées
create policy mc_select on public.mission_checks for select to authenticated
  using (student_id = auth.uid() or public.is_coach());
create policy mc_insert on public.mission_checks for insert to authenticated
  with check (student_id = auth.uid());
create policy mc_delete on public.mission_checks for delete to authenticated
  using (student_id = auth.uid());

-- Créneaux : tous les voient, seul le coach les modifie en direct
-- (les élèves réservent via les fonctions book_slot / cancel_slot)
create policy slots_select on public.slots for select to authenticated using (true);
create policy slots_coach  on public.slots for all to authenticated
  using (public.is_coach()) with check (public.is_coach());

-- Configuration
create policy cfg_select on public.app_config for select to authenticated using (true);
create policy cfg_coach  on public.app_config for all to authenticated
  using (public.is_coach()) with check (public.is_coach());

-- Droits : rien pour les visiteurs non connectés
revoke all on all tables    in schema public from anon;
revoke all on all functions in schema public from anon;

-- Un élève ne peut jamais changer son rôle ni son code via l'API
revoke update on public.profiles from authenticated;
grant  update (name, anon) on public.profiles to authenticated;

-- Les fonctions rpc ne sont appelables que par les comptes connectés
revoke execute on function public.create_slots(date, time, time, int) from public;
revoke execute on function public.book_slot(uuid)                     from public;
revoke execute on function public.cancel_slot(uuid)                   from public;
revoke execute on function public.leaderboard(text)                   from public;
revoke execute on function public.global_stats()                      from public;
grant  execute on function public.create_slots(date, time, time, int) to authenticated;
grant  execute on function public.book_slot(uuid)                     to authenticated;
grant  execute on function public.cancel_slot(uuid)                   to authenticated;
grant  execute on function public.leaderboard(text)                   to authenticated;
grant  execute on function public.global_stats()                      to authenticated;

-- ---------------------------------------------------------------------
-- 7. PREUVES DE PAIEMENT (stockage privé)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('proofs', 'proofs', false)
on conflict (id) do nothing;

-- Chemin attendu : <id_élève>/<fichier>
create policy proofs_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'proofs' and (storage.foldername(name))[1] = auth.uid()::text);
create policy proofs_select on storage.objects for select to authenticated
  using (bucket_id = 'proofs'
         and ((storage.foldername(name))[1] = auth.uid()::text or public.is_coach()));
create policy proofs_delete on storage.objects for delete to authenticated
  using (bucket_id = 'proofs' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------------------------------------------------------------------
-- 8. TEMPS RÉEL
-- ---------------------------------------------------------------------
alter publication supabase_realtime add table
  public.payments, public.activities, public.slots,
  public.mission_checks, public.missions, public.app_config;

-- ---------------------------------------------------------------------
-- 9. ACTIVER TON COMPTE COACH
-- Après t'être inscrit une première fois dans l'app, exécute :
--
--   update public.profiles set role = 'coach' where email = 'ton@email.fr';
--
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- 10. E-MAIL DE BIENVENUE (code d'inscription)
-- Rien à exécuter ici : l'envoi passe par un Database Webhook qui appelle
-- l'Edge Function "welcome-email" à chaque nouveau profil élève.
-- Étapes : voir le fichier supabase/functions/welcome-email/index.ts
-- ---------------------------------------------------------------------
